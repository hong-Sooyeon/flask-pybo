import os

BASE_DIR = os.path.dirname(os.path.dirname(__file__))